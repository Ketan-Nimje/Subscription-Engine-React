import Dashboard from "./Component/Dashboard/Dashboard";
import New from "./Component/SellingPlan/New";
import Listing from "./Component/SellingPlan/Listing";
import Plans from "./Component/PricingPlan/Plans";
import Settings from "./Component/Settings/Settings";
import NewSubscription from "./Component/Subscriptions/NewSubscription";
import SubscriptionDetails from "./Component/Subscriptions/SubscriptionDetails";
import GeneralSetting from "./Component/Settings/GeneralSetting";
import CustomerPortal from "./Component/Settings/CustomerPortal";
import Edit from "./Component/SellingPlan/Edit";
import SubscriptionList from "./Component/Subscriptions/SubscriptionList";
export const baseUrl = '/admin';
const routesList = [
  { path: `${baseUrl}/`, name: 'Dashboard', component: Dashboard, exact: true },
  { path: `${baseUrl}/dashboard`, name: 'Dashboard', component: Dashboard, exact: true },
  { path: `${baseUrl}/pricing-plan`, name: 'PricingPlan', component: Plans, exact: true },
  { path: `${baseUrl}/selling-plan-listing`, name: 'Listing', component: Listing, exact: true },
  { path: `${baseUrl}/selling-plan-new`, name: 'New', component: New, exact: true },
  { path: `${baseUrl}/selling-plan-edit/:id`, name: 'Edit Subscription Plan', component: Edit, exact: true },
  { path: `${baseUrl}/subscription`, name: 'Subscription', component: SubscriptionList, exact: true },
  { path: `${baseUrl}/subscription/:id`, name: 'Subscription Details', component: SubscriptionDetails, exact: true },
  { path: `${baseUrl}/new-subscription`, name: 'New Subscription', component: NewSubscription, exact: true },
  { path: `${baseUrl}/settings`, name: 'Settings', component: Settings, exact: true },
  { path: `${baseUrl}/layout-setting`, name: 'Settings', component: Plans, exact: true },
  { path: `${baseUrl}/general-setting`, name: 'General Setting', component: GeneralSetting, exact: true },
  { path: `${baseUrl}/customer-portal`, name: 'Custome Portal', component: CustomerPortal, exact: true },
  { path: `${baseUrl}/language`, name: 'Language', component: CustomerPortal, exact: true },
];
export default routesList;
export const apiKey = '136145be1651c43e63ffa3154c2e45a6';
export const urlParams = new URLSearchParams(window.location.search);




