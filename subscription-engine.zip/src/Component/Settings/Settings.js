import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
    Page,
    Card, Layout, ResourceList, TextStyle, Text, Thumbnail, Heading, DataTable, ButtonGroup, Button, Icon, FormLayout, TextField, Banner, Form, Stack, Select, ChoiceList, ResourceItem, Avatar
} from '@shopify/polaris';
import {
    AnalyticsMinor, ViewMajor, HorizontalDotsMinor, TemplateMajor, ManagedStoreMajor, LanguageMinor, ChatMajor, CreditCardMajor, NotificationMajor
} from '@shopify/polaris-icons';
import './../../App.css';

export default function Settings() {
    const navigation = useNavigate();

    function renderItem(item) {
        const { id, url, name, media, notes } = item;

        return <ResourceList.Item id={id} onClick={() => navigation(url)} media={media} accessibilityLabel={`View details for ${name}`}>
            <h3>
                <Text variant="bodyMd" as="span" fontWeight="semibold">{name}</Text>
            </h3>
            <div style={{ marginTop: '5px' }}>
                <Text variant="bodyMd" as="span" color="subdued">{notes}</Text>
            </div>
        </ResourceList.Item>;
    }
    return (
        <React.Fragment>
            <div className='settings'>
                <Page title="Settings">
                    <Card >
                        <Card.Section>
                            <Layout>
                                <Layout.Section oneThird>
                                    <ResourceList resourceName={{ singular: 'product', plural: 'products' }} items={[{
                                        id: 343,
                                        name: <Text variant="headingMd" as="h2">General Settings</Text>,
                                        sku: '9234194023',
                                        quantity: '254',
                                        url: `/admin/general-setting?${window.urlParams}`,
                                        media: <Thumbnail size="small" source={TemplateMajor} alt="Black orange scarf" />,
                                        notes: 'No supplier listed sdsd sd sds sdsdsd sdsdsds '
                                    }]}
                                        renderItem={renderItem}

                                    />
                                </Layout.Section>
                                <Layout.Section oneThird>
                                    <ResourceList resourceName={{ singular: 'product', plural: 'products' }} items={[{
                                        id: 343,
                                        name: <Text variant="headingMd" as="h2">Subscription Layout</Text>,
                                        sku: '9234194023',
                                        quantity: '254',
                                        url: `/admin/layout-setting?${window.urlParams}`,

                                        media: <Thumbnail size="small" source={TemplateMajor} alt="Black orange scarf" />,
                                        notes: 'No supplier listed sdsd sd sds sdsdsd sdsdsds '
                                    }]}
                                        renderItem={renderItem}

                                    />
                                </Layout.Section>
                                <Layout.Section oneThird>
                                    <ResourceList resourceName={{ singular: 'product', plural: 'products' }}
                                        items={[{
                                            id: 343,
                                            name: <Text variant="headingMd" as="h2">Customer portal settings</Text>,
                                            sku: '9234194023',
                                            quantity: '254',
                                            url: `/admin/customer-portal?${window.urlParams}`,

                                            media: <Thumbnail size="small" source={ManagedStoreMajor} alt="Black orange scarf" />,
                                            notes: 'No supplier listed sdsd sd sds sdsdsd sdsdsds '

                                        }]}
                                        renderItem={renderItem}
                                    />
                                </Layout.Section>
                                <Layout.Section oneThird>
                                    <ResourceList
                                        resourceName={{ singular: 'product', plural: 'products' }}
                                        items={[{
                                            id: 343,
                                            name: <Text variant="headingMd" as="h2">Language</Text>,
                                            sku: '9234194023',
                                            quantity: '254',
                                            url: `/admin/language?${window.urlParams}`,


                                            media: <Thumbnail size="small" source={LanguageMinor} alt="Black orange scarf" />,
                                            notes: 'No supplier listed sdsd sd sds sdsdsd sdsdsds '

                                        }]} renderItem={renderItem}
                                    />
                                </Layout.Section>
                                <Layout.Section oneThird>
                                    <ResourceList resourceName={{ singular: 'product', plural: 'products' }}
                                        items={[{
                                            id: 343,
                                            name: <Text variant="headingMd" as="h2">Cancel Feedback</Text>,
                                            sku: '9234194023',
                                            quantity: '254',
                                            url: `/admin/layout-setting?${window.urlParams}`,

                                            media: <Thumbnail size="small" source={ChatMajor} alt="Black orange scarf" />,
                                            notes: 'No supplier listed sdsd sd sds sdsdsd sdsdsds '

                                        }]} renderItem={renderItem}
                                    />

                                </Layout.Section>
                                <Layout.Section oneThird>
                                    <ResourceList resourceName={{ singular: 'notification', plural: 'notification' }} items={[{
                                        id: 343,
                                        name: <Text variant="headingMd" as="h2">Notification</Text>,
                                        sku: '9234194023',
                                        quantity: '254',
                                        url: `/admin/layout-setting?${window.urlParams}`,

                                        media: <Thumbnail size="small" source={NotificationMajor} alt="Black orange scarf" />,
                                        notes: 'No supplier listed sdsd sd sds sdsdsd sdsdsds'
                                    }]} renderItem={renderItem}
                                    />

                                </Layout.Section>
                            </Layout>
                        </Card.Section>

                    </Card>
                </Page >
            </div>
        </React.Fragment >
    );
}
