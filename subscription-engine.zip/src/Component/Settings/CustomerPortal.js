import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Page, Card, Layout, Checkbox, FormLayout, TextField, Select, ChoiceList } from '@shopify/polaris';
import { AnalyticsMinor, ViewMajor, HorizontalDotsMinor, TemplateMajor, ManagedStoreMajor, LanguageMinor, ChatMajor, CreditCardMajor, NotificationMajor } from '@shopify/polaris-icons';
import './../../App.css';

export default function CustomerPortal() {
    const navigation = useNavigate();
    return (
        <React.Fragment>
            <div>
                <Page title='Customer Portal' breadcrumbs={[{ content: 'Settings', onAction: () => navigation(`/admin/settings?${window.urlParams}`) }]}>
                    <Layout>
                        <Layout.AnnotatedSection
                            id="Customer-portal-management"
                            title="Customer Portal Management"
                        >
                            <Card sectioned>
                                <FormLayout>
                                    <Checkbox label="Show PAUSE/RESUME button in the customer portal"
                                        helpText="When turned on, customers will be able to pause/resume their subscriptions in the customer portal."
                                        checked={true}
                                    />
                                    <Checkbox label="Show CANCEL button in the customer portal"
                                        helpText="When turned on, customers will be able to cancelled their subscriptions in the customer portal."
                                        checked={true}
                                    />
                                    <Checkbox label="Show SKIP button in the customer portal"
                                        helpText="When turned on, customers will be able to skip their subscription in the customer portal."
                                        checked={true}
                                    />
                                    <Checkbox label="Allow customers to charge themselves at any time"
                                        helpText="This will show a Place order now button in the customer portal"
                                        checked={true}
                                    />
                                    <Checkbox label="Allow customers to change subscription interval"
                                        helpText="Customers will be able to change the subscription interval in the customer portal"
                                        checked={true}
                                    />
                                    <Checkbox label="Allow customers to change subscription next billing date"
                                        helpText="Customers will be able to change the subscription next billing date in the customer portal"
                                        checked={true}
                                    />
                                    <Checkbox label="Allow customers to enter a discount code"
                                        helpText="Customers will have an option to use a discount code on their subscriptions."
                                        checked={true}
                                    />
                                    <Checkbox label="Allow customers to add/remove products from the subscription"
                                        helpText="Customers will be able to remove and add products to the subscription. The shipping cost won't get updated when the customer adds/removes a product from the subscription."
                                        checked={true}
                                    />
                                    <Checkbox label="Allow customers to manage min/max no of time recurring order will place"
                                        checked={true}
                                    />
                                    <Checkbox label="Allow customers to change shipping address"
                                        checked={true}
                                    />
                                </FormLayout>
                            </Card>
                        </Layout.AnnotatedSection>
                    </Layout>
                </Page >
            </div>
        </React.Fragment >
    );
}
