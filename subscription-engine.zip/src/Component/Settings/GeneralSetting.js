import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
    Page,
    Card, Layout, Checkbox, Icon, FormLayout, TextField, Select, ChoiceList,
} from '@shopify/polaris';
import {
    AnalyticsMinor
} from '@shopify/polaris-icons';
import './../../App.css';

export default function GeneralSetting() {
    const navigation = useNavigate();
    const [selected, setSelected] = useState(1);
    const [choiceSelected, setChoiceSelected] = useState(['0']);

    const handleSelectChange = useCallback((value) => setSelected(value), []);
    const [textFieldValue, setTextFieldValue] = useState('');

    const handleChoiceListChange = useCallback((value) => setChoiceSelected(value), []);

    const handleTextFieldChange = useCallback(
        (value) => setTextFieldValue(value),
        [],
    );
    const renderChildren = useCallback(
        (isSelected) =>
            isSelected && (
                <TextField
                    label="Minimum Quantity"
                    labelHidden
                    onChange={handleTextFieldChange}
                    helpText="The shipping method name will be set on each subscription after it is created in the shop. Click the button below to set the shipping method name on your existing subscriptions."
                    value={textFieldValue}
                    autoComplete="off"
                />
            ),
        [handleTextFieldChange, textFieldValue],
    );


    return (
        <React.Fragment>
            <div>
                <Page title='General settings' breadcrumbs={[{ content: 'Products', onAction: () => navigation(`/admin/settings?${window.urlParams}`) }]}>
                    <Layout>
                        <Layout.AnnotatedSection
                            id="billing"
                            title="Billing settings"
                            description="Control how to bill your customers.">
                            <Card sectioned>
                                <FormLayout>
                                    <Select
                                        helpText="Configure how many times you want the system to retry the failed billing attempt before applying the action specified below."
                                        label="Retry failed billing attempts"
                                        options={[
                                            { label: "Don't retry", value: '0' },
                                            { label: '1 times', value: 1 },
                                            { label: '2 times', value: 2 },
                                            { label: '3 times', value: 3 },
                                            { label: '4 times', value: 4 },
                                        ]}
                                        onChange={handleSelectChange}
                                        value={selected}
                                    />
                                    <Select
                                        helpText="Configure the delay between the retries of a failed billing attempt."
                                        label="Delay between retries of a failed billing attempt"
                                        options={[
                                            { label: '1 Days', value: 1 },
                                            { label: '2 Days', value: 2 },
                                            { label: '3 Days', value: 3 },
                                            { label: '4 Days', value: 4 },
                                        ]}
                                        onChange={handleSelectChange}
                                        value={selected}
                                    />
                                    <Select
                                        helpText="Configure what to do when the payment fails multiple times."
                                        label="When the subscription reaches maximum number of failures"
                                        options={[
                                            { label: "Don't retry", value: 0 },
                                            { label: '1 times', value: 1 },
                                            { label: '2 times', value: 2 },
                                            { label: '3 times', value: 3 },
                                            { label: '4 times', value: 4 },
                                        ]}
                                        onChange={handleSelectChange}
                                        value={selected}
                                    />
                                </FormLayout>
                            </Card>
                        </Layout.AnnotatedSection>
                        <Layout.AnnotatedSection
                            id="shipping-for-auto-charging-subscriptions"
                            title="Shipping for auto-charging subscriptions"
                        // description="Choose when you want the system to automatically update the delivery cost in your subscriptions according to the shipping rates set up in your shop. The delivery cost will be automatically updated a few minutes after the change was applied to the subscription."
                        >
                            <Card >
                                <Card.Section>
                                    <Checkbox
                                        label="Update delivery cost for auto-charging subscription"
                                        checked={true}
                                        helpText="Turn this on if you want the app to automatically update the delivery cost of subscription according to your shipping rates after the subscription gets created. This resolves the issue if the customer got free shipping because they bought enough to get free shipping, but the subscription doesn't have enough products to have free shipping rate."
                                    />
                                </Card.Section>
                                <Card.Section title="SHIPPING METHOD NAME FOR SUBSCRIPTION RENEWALS">
                                    <FormLayout>
                                        <ChoiceList
                                            choices={[
                                                {
                                                    label: 'Default by Shopify',
                                                    value: 0,
                                                    helpText: 'The default shipping method, set by Shopify. Usually set as "Subscription shipping."',
                                                },
                                                {
                                                    label: 'Custom shipping method name',
                                                    value: 1,
                                                    renderChildren,
                                                },
                                            ]}
                                            selected={choiceSelected}
                                            onChange={handleChoiceListChange}
                                        />
                                    </FormLayout>
                                </Card.Section>
                            </Card>
                        </Layout.AnnotatedSection>
                        <Layout.AnnotatedSection
                            id='order'
                            title="Order Related settings"
                        // description="When an auto-charging subscription is purchased, the app can show a box with a description of the subscription, a link to the subscriptions and a button to resend the initial email."
                        >
                            <Card title="Order status page settings">
                                <Card.Section>
                                    <FormLayout>
                                        <Checkbox
                                            label="Show subscription box with link to the account"
                                            helpText="When the order contains an auto-charging subscription product, the app will add a box with instructions on how to access the subscription to the order status page."
                                            checked={true}
                                        />
                                    </FormLayout>
                                </Card.Section>
                                <Card.Section title="Orders tag setting">
                                    <FormLayout>
                                        <Checkbox
                                            label="Tag subscription first order and recurring order"
                                            checked={true}
                                        />
                                        <TextField label="First subscription order tag" helpText="Each new subscription order will be tagged with this tag." />
                                        <TextField label="Subsequent/Recurring subscription order tag" helpText="Each subsequent/recurring subscription order will be tagged with this tag. You can separate tags with commas and use the placeholders listed below to add additional info to the tag." />
                                    </FormLayout>
                                </Card.Section>
                            </Card>
                        </Layout.AnnotatedSection>
                    </Layout>
                </Page >
            </div>
        </React.Fragment >
    );
}
